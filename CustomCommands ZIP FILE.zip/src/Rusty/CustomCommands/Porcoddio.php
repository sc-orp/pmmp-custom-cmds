<?php

namespace Rusty\CustomCommands;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;


class Porcoddio extends PluginBase {

    public function onLoad(){      
   $this->getServer()->getCommandMap()->unregister($this->getServer()->getCommandMap()->getCommand("plugins"));
        $this->getServer()->getCommandMap()->unregister($this->getServer()->getCommandMap()->getCommand("ver")); 
        $this->getServer()->getLogger()->info("§aCustom /plugins, /pl, /ver, /version & /about enabled.");
    }

    public function onCommand(CommandSender $sender, Command $cmd, string $label, array $args) : bool{
              if($cmd->getName() === "plugins") {
                $sender->sendMessage($this->getConfig()->get("plugins"));
                return true;
           }
              if($cmd->getName() === "pl") {
                $sender->sendMessage($this->getConfig()->get("pl"));
                return true;
           }
              if($cmd->getName() === "version") {
                $sender->sendMessage($this->getConfig()->get("version"));
                return true;
           }
              if($cmd->getName() === "ver") {
                $sender->sendMessage($this->getConfig()->get("ver"));
                return true;
           }
              if($cmd->getName() === "about") {
                $sender->sendMessage($this->getConfig()->get("about"));
                return true;
           }
          return false;
          }
}